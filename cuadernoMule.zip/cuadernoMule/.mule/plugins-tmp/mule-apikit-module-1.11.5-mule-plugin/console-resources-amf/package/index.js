// Template index.js Add exports if necessary.
module.exports = console.log('This is a bundler script that generates production ready sources for API Console.')
